library(testthat)
library(mgatk)

test_check("mgatk")
