#' mgatk: a mitochondrial genome analysis toolkit
#'
#' The mgatk R package implements
#'
#' @docType package
#' @useDynLib mgatk
#' @name mgatk
NULL
